---
name: industry_research_report
description: >
  依托东方财富数据库，为指定行业生成深度研究报告。
  当用户问题中出现可识别的行业/产业/领域主体，且意图属于行业认知、产业剖析或撰写研究报告时，应触发本 Skill。
  常见表述如「XX 行业研究」「XX 行业报告」「帮我分析 XX 行业」「XX 产业深度研究」「XX 领域市场分析」等。
  即使用户未明说「报告」，只要以某一行业为核心、要求系统性或深度的研究/分析，同样适用。
metadata:
  {
    "openclaw": {
      "requires": {
        "env":["EM_API_KEY"]
      },
      "install": [
        {
          "id": "pip-deps",
          "kind": "python",
          "package": "httpx",
          "label": "Install Python dependencies"
        }
      ]
    }
  }
---

# 行业研究报告生成 Skill

## 概述

本 Skill 用于根据用户的自由输入，使用模型提取行业关键词，调用行业研究脚本生成研究报告，最终输出包含最终返回标题、正文、PDF/DOC附件地址。

## 环境变量

| 变量名 | 说明 | 默认 |
|---|---|---|
| `EM_API_KEY` | 接口鉴权密钥（必填，请勿打印/写入日志） | 无 |
| `INDUSTRY_RESEARCH_REPORT_OUTPUT_DIR` | 报告文件输出目录（可选） | `./miaoxiang/industry_research_report` |

## 前提条件

### 1. 配置 `EM_API_KEY`

```bash
# macOS / Linux
export EM_API_KEY="your_api_key_here"
```

```powershell
# Windows PowerShell
$env:EM_API_KEY="your_api_key_here"
```

### 2. 安装依赖

```bash
pip3 install httpx --user
```

## 执行流程

### Step 1：提取行业关键词 `{{topic}}`

用户的输入形式较为自由，可能是一句话、一个短语或一段描述，但一定包含"行业主体"这一关键信息。

**你需要做的：**
- 从用户问句中精准提取行业关键词，记为 `{{topic}}`。
- 提取时只保留核心行业主体名称，去除多余的修饰词（如"帮我看看"、"分析一下"等）。
- 如果用户问句中包含多个行业，优先提取最核心的那个（也可以在必要时合并，如"新能源汽车"）。

**示例：**

| 用户输入 | 提取的 `{{topic}}` |
|---|---|
| "帮我生成一份半导体行业的研究报告" | 半导体 |
| "我想了解一下新能源汽车产业的发展趋势" | 新能源汽车 |
| "AI芯片行业深度分析" | AI芯片 |
| "请分析消费电子与智能家居两个领域的交叉趋势" | 消费电子与智能家居 |

### Step 2：调用行业研究报告写作脚本

以 `{{topic}}` 为入参，调用`scripts/get_data.py` 行业研究脚本：

```bash
python3 {baseDir}/scripts/get_data.py --query "{{topic}}"
```

脚本功能：生成相应的行业研究报告并将其分别用pdf和docx的格式保存。

脚本返回字段说明：

```
{
    "title": "生成的报告标题",
    "truncated_text": "研究报告的部分正文内容",
    "pdf_output_path": "完整报告的pdf文件保存地址",
    "docx_output_path": "完整报告的docx文件保存地址",
    "share_url": "完整报告的分享链接"
}
```

注意：**禁止调用 任何「后台执行、稍后汇报」的方式跑本脚本**，只能在当前会话中同步等待到命令完成，拿到 stdout 的结果后再继续。否则 Step 3 无法执行，从而导致本 Skill 失败。

### Step 3：最终输出结果

Step 2 成功后，将返回的 title、truncated_text、pdf_output_dir、docx_output_dir 等结果填入下方模板，生成最终回复。

```
《[title]》

已经生成行业研究报告。此处仅展示部分正文内容，请下载附件查看报告详情和参考信息。（不要删减这段话）

[truncated_text]...

**附件：**
- 📄 [title].pdf 已保存到 [pdf_output_path]
- 📄 [title].docx 已保存到 [docx_output_path]

**分享链接：**
[share_url]
```

注意：若Step 2中的脚本返回的[truncated_text]部分为空，则读取接口返回的docx附件内容，总结相关报告信息返回，以确保最终输出的[truncated_text]内容非空。

## 错误处理

| 错误码 | 含义 | 用户侧话术 |
|---|---|---|
| `ERROR_TOPIC_TOO_LONG` | topic 超出 500 字限制 | "字数超出限制，请尝试其它主体。" |
| 其他异常 | 接口调用失败等 | "报告生成服务暂时不可用，请稍后重试。" |

## 安全与隐私提示（必读）

- **密钥安全**：`EM_API_KEY` 属于敏感信息，只应配置在可信环境中，禁止写入日志/截图/共享给不可信第三方。
- **文件落盘**：脚本会写入本地文件。请通过环境变量 `INDUSTRY_RESEARCH_REPORT_OUTPUT_DIR` 指定保存位置，确保目录可写且符合你的合规要求。
- **外链谨慎**：服务端可能返回分享链接，请仅在你信任的网络环境中打开，并留意域名与跳转。
